// [신규 파일] CH3MinimapCaptureActor.h
// [클래스 종류: Actor] Add C++ Class 마법사에서 "Actor" 선택 후,
//                      생성된 파일 내용을 이 코드로 교체하면 됩니다.
//
// 역할: 게임 시작 시 맵 전체를 위에서 "딱 한 번" 촬영해서 RenderTarget에 저장.
//       이후에는 다시 안 찍으므로 매 프레임 렌더링 비용이 없음.
//
// [왜 이 방식인가 - 선택지 비교]
//   1) PNG 스크린샷: 촬영 해상도가 고정 → 확대 시 화질 깨짐 (기존 문제)
//   2) 매 프레임 SceneCapture: 화질 좋지만 GPU가 씬을 매 프레임 2번 그림 → 낭비
//   3) 1회 캡쳐(이 방식): RenderTarget 해상도를 크게(2048~4096) 잡으면
//      확대해도 선명 + 비용은 게임 시작 시 1번뿐 → 고정 맵에 최적
//
// [객체지향 포인트 - Single Source of Truth(단일 진실 공급원)]
//   미니맵 좌표 계산에 필요한 "촬영 범위" 값을 이 액터가 소유하고,
//   HUD는 이 액터에게 물어봐서(Getter) 가져다 씀.
//   → 촬영 범위를 바꿀 때 이 액터의 값 하나만 고치면 HUD 계산이 자동으로 맞춰짐.
//   (예전 방식: HUD에 좌표를 하드코딩 → 카메라 옮길 때마다 두 군데를 고쳐야 했음)

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "CH3MinimapCaptureActor.generated.h"

class USceneCaptureComponent2D;

UCLASS()
class CH3TEAMP_API ACH3MinimapCaptureActor : public AActor
{
	GENERATED_BODY()

public:
	ACH3MinimapCaptureActor();

	/** HUD가 좌표 계산에 쓸 "촬영된 월드 영역의 좌상단 좌표"를 돌려줌 */
	FVector2D GetMinimapWorldOrigin() const;

	/** HUD가 좌표 계산에 쓸 "촬영된 월드 영역의 가로/세로 크기"를 돌려줌
	 *  RenderTarget을 정사각형으로 쓰므로 가로 = 세로 = OrthoWidth */
	FVector2D GetMinimapWorldSize() const;

protected:
	virtual void BeginPlay() override;

	/** 실제 촬영을 담당하는 카메라 컴포넌트 */
	UPROPERTY(VisibleAnywhere, Category = "Minimap")
	USceneCaptureComponent2D* CaptureComponent;

	/** 촬영 범위(월드 유닛). 맵 전체가 들어가도록 설정.
	 *  기존 계산: 맵 폭 약 607,060 / 높이 약 583,440 → 여유 포함 620,000 */
	UPROPERTY(EditAnywhere, Category = "Minimap", meta = (ClampMin = "1"))
	float OrthoWidth = 620000.f;
};