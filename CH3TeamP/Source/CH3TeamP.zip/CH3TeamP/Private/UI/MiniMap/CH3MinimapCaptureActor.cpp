// [신규 파일] CH3MinimapCaptureActor.cpp

#include "UI/MiniMap/CH3MinimapCaptureActor.h"
#include "Components/SceneCaptureComponent2D.h"

ACH3MinimapCaptureActor::ACH3MinimapCaptureActor()
{
	// 미니맵은 한 번만 찍으면 되므로 Tick 자체를 꺼서 비용 0으로.
	PrimaryActorTick.bCanEverTick = false;

	CaptureComponent = CreateDefaultSubobject<USceneCaptureComponent2D>(TEXT("CaptureComponent"));
	RootComponent = CaptureComponent;

	// ── 핵심 설정 1: 자동 촬영 전부 끄기 ──
	// bCaptureEveryFrame=true(기본값)면 매 프레임 씬을 다시 그려서 GPU 낭비.
	// false로 끄고, 아래 BeginPlay에서 CaptureScene()을 "직접 한 번만" 호출한다.
	CaptureComponent->bCaptureEveryFrame = false;
	CaptureComponent->bCaptureOnMovement = false; // 액터가 움직여도 재촬영 안 함

	// ── 핵심 설정 2: 직교(Orthographic) 투영 ──
	// 원근(Perspective)으로 찍으면 가장자리가 왜곡되어 좌표 계산이 틀어짐.
	// 직교로 찍어야 "이미지의 픽셀 비율 = 월드 거리 비율"이 정확히 성립.
	CaptureComponent->ProjectionType = ECameraProjectionMode::Orthographic;

	// ── 핵심 설정 3: 캡쳐 결과물 종류 ──
	// SCS_FinalColorLDR = 라이팅/포스트프로세스가 적용된 "눈에 보이는 그대로"의 색.
	// (SCS_SceneColorHDR 등은 톤매핑 전 원본이라 미니맵용으론 어둡거나 물빠져 보임)
	CaptureComponent->CaptureSource = ESceneCaptureSource::SCS_FinalColorLDR;

	// 수직으로 내려다보는 각도 (에디터에서 배치 후 바꿔도 됨)
	CaptureComponent->SetRelativeRotation(FRotator(-90.f, 0.f, 0.f));
}

void ACH3MinimapCaptureActor::BeginPlay()
{
	Super::BeginPlay();

	if (CaptureComponent)
	{
		// 에디터에서 조정한 OrthoWidth 값을 컴포넌트에 반영
		CaptureComponent->OrthoWidth = OrthoWidth;

		// ★ 게임 시작 시 딱 한 번만 촬영 ★
		// 이 한 줄이 "정적 이미지의 성능 + 실시간 캡쳐의 화질"을 모두 갖게 해줌.
		// TextureTarget(RenderTarget 애셋)은 에디터의 Details 패널에서 연결한다.
		CaptureComponent->CaptureScene();
	}
}

FVector2D ACH3MinimapCaptureActor::GetMinimapWorldOrigin() const
{
	// 촬영 중심(액터 위치)에서 반폭만큼 뺀 지점 = 이미지의 좌상단이 가리키는 월드 좌표
	const FVector Center = GetActorLocation();
	const float Half = OrthoWidth * 0.5f;
	return FVector2D(Center.X - Half, Center.Y - Half);
}

FVector2D ACH3MinimapCaptureActor::GetMinimapWorldSize() const
{
	// RenderTarget을 정사각형(예: 2048x2048)으로 만들면
	// 세로 촬영 범위도 OrthoWidth와 같아져서 계산이 단순해진다.
	// (직사각 RT를 쓰면 세로 = OrthoWidth * RT세로/RT가로 로 따로 계산해야 함)
	return FVector2D(OrthoWidth, OrthoWidth);
}